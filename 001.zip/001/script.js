(function() {
    // ========== 数据模型 ==========
    const BaijiRoutes = {
        "routes": [
            {
              "id": "red-tour",
              "name": "路线一：红色游",
              "duration": "1日",
              "color": "#C41E3A",
              "mapCenter": [29.7, 118.5],
              "points": [
                { "id": "commune", "name": "白际人民公社旧址", "latlng": [29.71, 118.51], "icon": "red-star", "description": "参观\"两山馆\"，看60年代的老物件，听讲解员讲述大集体时代的故事。", "category": "red" },
                { "id": "ancient-road", "name": "徽开古道徒步", "latlng": [29.72, 118.52], "icon": "green-leaf", "description": "沿着青石板路徒步约2公里（平缓路段），寻找古道旁的\"红军标语墙\"遗址，体验当年红军的行军环境。", "category": "green" },
                { "id": "shishi-base", "name": "狮石红色教育基地", "latlng": [29.73, 118.53], "icon": "red-star", "description": "核心展馆：红色狮石革命村史馆（程氏树德堂），记录方志敏红军战斗历史。特色展馆：清贫文化礼堂，弘扬方志敏《清贫》精神。", "category": "red" }
              ]
            },
            {
              "id": "nature-tour",
              "name": "路线二：自然游<br>（森林康养）",
              "duration": "2日自驾",
              "color": "#228B22",
              "mapCenter": [29.7, 118.5],
              "points": [
                { "id": "viewpoint", "name": "徽州天路观景台", "latlng": [29.74, 118.54], "icon": "green-leaf", "description": "挑战\"华东第一弯\"，在最高点观景台停车，拍摄云海和盘山公路的\"上帝视角\"。" },
                { "id": "terraces", "name": "严池高山梯田", "latlng": [29.75, 118.55], "icon": "yellow-wheat", "description": "徒步木栈道，春天看油菜花海，夏天看翡翠梯田，秋天看金色稻浪。" },
                { "id": "waterfall", "name": "百丈冲瀑布群", "latlng": [29.76, 118.56], "icon": "blue-water", "description": "亲水徒步，拍摄飞流直下的瀑布，夏天可在此戏水纳凉。" }
              ]
            },
            {
              "id": "family-tour",
              "name": "路线三：亲子/研学游",
              "duration": "3日",
              "color": "#FF8C00",
              "mapCenter": [29.7, 118.5],
              "points": [
                { "id": "canyon", "name": "白际大峡谷", "latlng": [29.77, 118.57], "icon": "blue-water", "description": "穿上雨靴，在大峡谷里寻找奇形怪状的石头和昆虫，做自然笔记。" },
                { "id": "water-gun", "name": "瀑布水枪", "latlng": [29.78, 118.58], "icon": "yellow-star", "description": "安全水域内的亲子互动游戏，释放孩子天性。" },
                { "id": "star-gazing", "name": "星空观测点", "latlng": [29.79, 118.59], "icon": "yellow-star", "description": "白际乡光污染极少，用天文望远镜观测银河和星座。" }
              ]
            },
            {
              "id": "agri-tour",
              "name": "路线四：非遗/务农游",
              "duration": "2日",
              "color": "#8B4513",
              "mapCenter": [29.7, 118.5],
              "points": [
                { "id": "oil-mill", "name": "传统榨油坊", "latlng": [29.80, 118.60], "icon": "yellow-wheat", "description": "观看传统木榨榨油的过程，了解菜籽油的制作工艺。" },
                { "id": "fire-cooking", "name": "土灶大锅饭", "latlng": [29.81, 118.61], "icon": "red-fire", "description": "在严池村民家中，体验用大铁锅炒菜、烧柴火饭。" },
                { "id": "tea-picking", "name": "采茶制茶", "latlng": [29.82, 118.62], "icon": "green-leaf", "description": "在茶园采摘茶叶，跟着师傅学习杀青和揉捻。" }
              ]
            }
          ],
          "specialties": [ "白际红薯干", "笋干", "土鸡蛋", "高山云雾茶", "野生葛粉" ]
    };

    // 初始化地图
    const firstRoute = BaijiRoutes.routes[0];
    const startPoint = firstRoute.points[0].latlng;
    const map = L.map('map').setView(startPoint, 13);
    L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
        subdomains: '1234',
        attribution: '高德地图'
    }).addTo(map);

    let currentMarkers = [];
    let currentPolyline = null;
    let activeRouteId = null;

    function getIconByCategory(category, routeColor = '#C41E3A') {
        let html = '';
        if (category === 'red' || category === 'red-star') html = '<div style="background:#C41E3A; width:30px; height:30px; border-radius:50% 10% 50% 50%; display:flex; align-items:center; justify-content:center; border:2px solid white; box-shadow:0 2px 6px black;"><span style="color:white; font-size:20px;">★</span></div>';
        else if (category === 'green' || category === 'green-leaf') html = '<div style="background:#2E8B57; width:32px; height:32px; border-radius:50% 0 50% 0; display:flex; align-items:center; justify-content:center; border:2px solid #f5e2c1;"><span style="color:white; font-size:20px;">🌿</span></div>';
        else if (category === 'yellow-wheat') html = '<div style="background:#D4AF37; width:32px; height:32px; border-radius:4px 50% 4px 50%; display:flex; align-items:center; justify-content:center; border:2px solid #644117;"><span style="font-size:20px;">🌾</span></div>';
        else if (category === 'blue-water') html = '<div style="background:#4682B4; width:32px; height:32px; border-radius:30% 70% 30% 30%; display:flex; align-items:center; justify-content:center; border:2px solid #f0e6d2;"><span style="color:white; font-size:20px;">💧</span></div>';
        else if (category === 'yellow-star') html = '<div style="background:#FFD700; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid #b8860b;"><span style="font-size:20px;">⭐</span></div>';
        else if (category === 'red-fire') html = '<div style="background:#E25822; width:32px; height:32px; border-radius:10% 60% 10% 60%; display:flex; align-items:center; justify-content:center; border:2px solid #4a251b;"><span style="color:white;">🔥</span></div>';
        else html = '<div style="background:#999; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white;"><span>📍</span></div>';
        
        return L.divIcon({ className: 'custom-marker', html: html, iconSize: [34, 34], popupAnchor: [0, -18] });
    }

    function clearLayers() {
        currentMarkers.forEach(m => map.removeLayer(m));
        currentMarkers = [];
        if (currentPolyline) map.removeLayer(currentPolyline);
    }

    function loadRouteMap(routeId) {
        const route = BaijiRoutes.routes.find(r => r.id === routeId);
        if (!route) return;
        activeRouteId = routeId;
        clearLayers();

        // 设置地图中心到该路线的第一个图标上
        if (route.points.length > 0) {
            map.flyTo(route.points[0].latlng, 13, { duration: 1.8 });
        }

        const pointLatLngs = route.points.map(p => p.latlng);
        currentPolyline = L.polyline(pointLatLngs, { 
            color: route.color, 
            weight: 3, 
            opacity: 0.8, 
            dashArray: '8, 6', 
            interactive: false,
            renderer: L.canvas()
        }).addTo(map);
        
        // 立即强制重绘
        setTimeout(() => {
            if (currentPolyline._renderer) {
                currentPolyline._renderer._update();
            }
        }, 10);

        route.points.forEach(point => {
            const icon = getIconByCategory(point.icon || point.category, route.color);
            const marker = L.marker(point.latlng, { icon }).addTo(map);
            
            let popupClass = 'custom-popup-red';
            if (routeId === 'nature-tour') popupClass = 'custom-popup-green';
            else if (routeId === 'family-tour') popupClass = 'custom-popup-orange';
            else if (routeId === 'agri-tour') popupClass = 'custom-popup-brown';
            
            // 为白际人民公社标记添加图片轮播弹窗
            if (point.name.includes('白际人民公社')) {
                const popupContent = `
                    <b style="font-size:1.1rem;">${point.name}</b><br>
                    <span style="font-size:0.9rem;">${point.description}</span>
                    <div style="margin-top:10px;">
                    <div style="font-size:0.8rem; margin-bottom:8px;"><i class="fas fa-camera"></i> 实景影像</div>
                    <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                        <img src="./白际人民公社/1.jpg" alt="白际人民公社旧址" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0;" class="commune-img active">
                        <img src="./白际人民公社/2.jpg" alt="白际人民公社旧址" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0;" class="commune-img">
                        <img src="./白际人民公社/3.jpg" alt="白际人民公社旧址" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0;" class="commune-img">
                        <img src="./白际人民公社/4.jpg" alt="白际人民公社旧址" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0;" class="commune-img">
                        <img src="./白际人民公社/5.jpg" alt="白际人民公社旧址" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0;" class="commune-img">
                    </div>
                        <div class="commune-indicators" style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                        <span class="commune-indicator active" onclick="showCommuneImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                        <span class="commune-indicator" onclick="showCommuneImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                        <span class="commune-indicator" onclick="showCommuneImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                        <span class="commune-indicator" onclick="showCommuneImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                        <span class="commune-indicator" onclick="showCommuneImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                    </div>
                        <div style="text-align:center; margin-top:3px; font-size:0.6rem; color:#999;">
                            点击圆点切换图片
                        </div>
                    </div>
                    <small style="font-size:0.7rem;">👣 类别: ${point.category}</small>
                `;
                
                marker.bindPopup(popupContent, { 
                    className: popupClass,
                    maxWidth: 220,
                    closeOnClick: false,  // 点击地图不关闭弹窗
                    autoClose: false,     // 鼠标离开标记不自动关闭
                    closeOnEscapeKey: false // 按ESC键不关闭弹窗
                });
                
                // 启动自动轮播
                marker.on('popupopen', function() {
                    startCommuneCarousel();
                });
                
                // 简单的弹窗控制：鼠标移到弹窗上不消失
            marker.on('popupopen', function() {
                // 禁用自动关闭
                if (marker._popup) {
                    marker._popup.options.autoClose = false;
                    
                    // 给弹窗添加鼠标事件
                    const popupElement = marker._popup.getElement();
                    if (popupElement) {
                        // 鼠标进入弹窗 - 保持打开
                        popupElement.addEventListener('mouseenter', function() {
                            // 弹窗保持打开
                        });
                        
                        // 鼠标离开弹窗 - 关闭
                        popupElement.addEventListener('mouseleave', function() {
                            marker.closePopup();
                        });
                    }
                }
            });
            
            // 标记鼠标离开时，检查鼠标是否在弹窗上
            marker.on('mouseout', function(e) {
                const popupElement = marker.getPopup()?.getElement();
                if (popupElement) {
                    // 延迟检查，给鼠标时间移动到弹窗
                    setTimeout(() => {
                        const popupRect = popupElement.getBoundingClientRect();
                        const mouseX = e.originalEvent.clientX;
                        const mouseY = e.originalEvent.clientY;
                        
                        // 如果鼠标在弹窗区域内，不关闭弹窗
                        const isMouseInPopup = mouseX >= popupRect.left && mouseX <= popupRect.right &&
                                              mouseY >= popupRect.top && mouseY <= popupRect.bottom;
                        
                        if (!isMouseInPopup) {
                            marker.closePopup();
                        }
                    }, 100);
                } else {
                    marker.closePopup();
                }
            });
                
                marker.on('popupclose', function() {
                    stopCommuneCarousel();
                });
            } else if (point.id === 'ancient-road') {
                // 徽开古道弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">徽开古道</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            徽开古道是古代徽州通往浙江开化的商道，全长约25公里，沿途风景秀丽，历史文化底蕴深厚。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            古道徒步、自然风光、历史文化
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="徽开古道/1.jpg" alt="徽开古道照片1" class="huikai-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="徽开古道/2.jpg" alt="徽开古道照片2" class="huikai-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽开古道/3.jpg" alt="徽开古道照片3" class="huikai-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽开古道/4.jpg" alt="徽开古道照片4" class="huikai-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽开古道/5.jpg" alt="徽开古道照片5" class="huikai-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="huikai-indicator active" onclick="showHuikaiImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="huikai-indicator" onclick="showHuikaiImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huikai-indicator" onclick="showHuikaiImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huikai-indicator" onclick="showHuikaiImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huikai-indicator" onclick="showHuikaiImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startHuikaiCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopHuikaiCarousel();
                });
            } else if (point.id === 'shishi-base') {
                // 狮石红色教育基地弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">狮石红色教育基地</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            核心展馆：红色狮石革命村史馆（程氏树德堂），记录方志敏红军战斗历史。特色展馆：清贫文化礼堂，弘扬方志敏《清贫》精神。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            革命历史、红色文化、爱国主义教育
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="红狮教育基地/1.jpg" alt="狮石红色教育基地照片1" class="shishi-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="红狮教育基地/2.jpg" alt="狮石红色教育基地照片2" class="shishi-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="红狮教育基地/3.jpg" alt="狮石红色教育基地照片3" class="shishi-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="红狮教育基地/4.jpg" alt="狮石红色教育基地照片4" class="shishi-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="红狮教育基地/5.jpg" alt="狮石红色教育基地照片5" class="shishi-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="shishi-indicator active" onclick="showShishiImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="shishi-indicator" onclick="showShishiImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="shishi-indicator" onclick="showShishiImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="shishi-indicator" onclick="showShishiImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="shishi-indicator" onclick="showShishiImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startShishiCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopShishiCarousel();
                });
            } else if (point.id === 'viewpoint') {
                // 徽州天路观景台弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">徽州天路观景台</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            挑战"华东第一弯"，在最高点观景台停车，拍摄云海和盘山公路的"上帝视角"。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            华东第一弯、云海景观、盘山公路
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="徽州天路/1.jpg" alt="徽州天路照片1" class="huizhou-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="徽州天路/2.jpg" alt="徽州天路照片2" class="huizhou-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽州天路/3.jpg" alt="徽州天路照片3" class="huizhou-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽州天路/4.jpg" alt="徽州天路照片4" class="huizhou-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="徽州天路/5.jpg" alt="徽州天路照片5" class="huizhou-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="huizhou-indicator active" onclick="showHuizhouImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="huizhou-indicator" onclick="showHuizhouImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huizhou-indicator" onclick="showHuizhouImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huizhou-indicator" onclick="showHuizhouImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="huizhou-indicator" onclick="showHuizhouImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startHuizhouCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopHuizhouCarousel();
                });
            } else if (point.id === 'terraces') {
                // 严池高山梯田弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">严池高山梯田</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            徒步木栈道，春天看油菜花海，夏天看翡翠梯田，秋天看金色稻浪。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            四季景观、徒步木栈道、梯田风光
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="白际严池/1.jpg" alt="严池高山梯田照片1" class="terraces-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="白际严池/2.jpg" alt="严池高山梯田照片2" class="terraces-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="白际严池/3.jpg" alt="严池高山梯田照片3" class="terraces-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="白际严池/4.jpg" alt="严池高山梯田照片4" class="terraces-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="白际严池/5.jpg" alt="严池高山梯田照片5" class="terraces-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="terraces-indicator active" onclick="showTerracesImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="terraces-indicator" onclick="showTerracesImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="terraces-indicator" onclick="showTerracesImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="terraces-indicator" onclick="showTerracesImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="terraces-indicator" onclick="showTerracesImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startTerracesCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopTerracesCarousel();
                });
            } else if (point.id === 'canyon') {
                // 白际大峡谷弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">白际大峡谷</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            穿上雨靴，在大峡谷里寻找奇形怪状的石头和昆虫，做自然笔记。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            峡谷探险、奇石观赏、自然笔记
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="大峡谷/1.jpg" alt="白际大峡谷照片1" class="canyon-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="大峡谷/2.jpg" alt="白际大峡谷照片2" class="canyon-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大峡谷/3.jpg" alt="白际大峡谷照片3" class="canyon-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大峡谷/4.jpg" alt="白际大峡谷照片4" class="canyon-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大峡谷/5.jpg" alt="白际大峡谷照片5" class="canyon-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="canyon-indicator active" onclick="showCanyonImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="canyon-indicator" onclick="showCanyonImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="canyon-indicator" onclick="showCanyonImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="canyon-indicator" onclick="showCanyonImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="canyon-indicator" onclick="showCanyonImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startCanyonCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopCanyonCarousel();
                });
            } else if (point.id === 'water-gun') {
                // 瀑布水枪弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">瀑布水枪</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            安全水域内的亲子互动游戏，释放孩子天性。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            亲子互动、水上游戏、安全水域
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="瀑布水枪/1.jpg" alt="瀑布水枪照片1" class="watergun-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="瀑布水枪/2.jpg" alt="瀑布水枪照片2" class="watergun-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布水枪/3.jpg" alt="瀑布水枪照片3" class="watergun-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布水枪/4.jpg" alt="瀑布水枪照片4" class="watergun-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布水枪/5.jpg" alt="瀑布水枪照片5" class="watergun-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="watergun-indicator active" onclick="showWatergunImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="watergun-indicator" onclick="showWatergunImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="watergun-indicator" onclick="showWatergunImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="watergun-indicator" onclick="showWatergunImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="watergun-indicator" onclick="showWatergunImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startWatergunCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopWatergunCarousel();
                });
            } else if (point.id === 'oil-mill') {
                // 传统榨油坊弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">传统榨油坊</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            观看传统木榨榨油的过程，了解菜籽油的制作工艺。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            传统工艺、手工榨油、文化体验
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="传统榨油坊/1.jpg" alt="传统榨油坊照片1" class="oilmill-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="传统榨油坊/2.jpg" alt="传统榨油坊照片2" class="oilmill-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="传统榨油坊/3.jpg" alt="传统榨油坊照片3" class="oilmill-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="传统榨油坊/4.jpg" alt="传统榨油坊照片4" class="oilmill-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="传统榨油坊/5.jpg" alt="传统榨油坊照片5" class="oilmill-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="oilmill-indicator active" onclick="showOilmillImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="oilmill-indicator" onclick="showOilmillImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="oilmill-indicator" onclick="showOilmillImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="oilmill-indicator" onclick="showOilmillImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="oilmill-indicator" onclick="showOilmillImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startOilmillCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopOilmillCarousel();
                });
            } else if (point.id === 'tea-picking') {
                // 采茶制茶弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">采茶制茶</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            在茶园采摘茶叶，跟着师傅学习杀青和揉捻。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            茶园采摘、手工制茶、文化体验
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="茶/1.jpg" alt="采茶制茶照片1" class="tea-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="茶/2.jpg" alt="采茶制茶照片2" class="tea-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="茶/3.jpg" alt="采茶制茶照片3" class="tea-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="茶/4.jpg" alt="采茶制茶照片4" class="tea-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="茶/5.jpg" alt="采茶制茶照片5" class="tea-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="tea-indicator active" onclick="showTeaImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="tea-indicator" onclick="showTeaImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="tea-indicator" onclick="showTeaImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="tea-indicator" onclick="showTeaImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="tea-indicator" onclick="showTeaImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startTeaCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopTeaCarousel();
                });
            } else if (point.id === 'fire-cooking') {
                // 土灶大锅饭弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">土灶大锅饭</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            在严池村民家中，体验用大铁锅炒菜、烧柴火饭。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            农家体验、柴火饭、传统烹饪
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="大锅饭/1.jpg" alt="土灶大锅饭照片1" class="firecooking-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="大锅饭/2.jpg" alt="土灶大锅饭照片2" class="firecooking-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大锅饭/3.jpg" alt="土灶大锅饭照片3" class="firecooking-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大锅饭/4.jpg" alt="土灶大锅饭照片4" class="firecooking-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="大锅饭/5.jpg" alt="土灶大锅饭照片5" class="firecooking-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="firecooking-indicator active" onclick="showFirecookingImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="firecooking-indicator" onclick="showFirecookingImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="firecooking-indicator" onclick="showFirecookingImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="firecooking-indicator" onclick="showFirecookingImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="firecooking-indicator" onclick="showFirecookingImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startFirecookingCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopFirecookingCarousel();
                });
            } else if (point.id === 'star-gazing') {
                // 星空观测点弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">星空观测点</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            白际乡光污染极少，用天文望远镜观测银河和星座。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            星空观测、天文科普、夜间活动
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="星空/1.jpg" alt="星空观测点照片1" class="star-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="星空/2.jpg" alt="星空观测点照片2" class="star-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="星空/3.jpg" alt="星空观测点照片3" class="star-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="星空/4.jpg" alt="星空观测点照片4" class="star-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="星空/5.jpg" alt="星空观测点照片5" class="star-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="star-indicator active" onclick="showStarImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="star-indicator" onclick="showStarImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="star-indicator" onclick="showStarImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="star-indicator" onclick="showStarImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="star-indicator" onclick="showStarImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startStarCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopStarCarousel();
                });
            } else if (point.id === 'waterfall') {
                // 百丈冲瀑布群弹窗内容
                const popupContent = `
                    <div class="popup-content" style="text-align:center; max-width:240px;">
                        <h4 style="margin:0 0 10px 0; color:#C41E3A;">百丈冲瀑布群</h4>
                        <p style="margin:0 0 10px 0; font-size:12px; color:#666;">
                            亲水徒步，拍摄飞流直下的瀑布，夏天可在此戏水纳凉。
                        </p>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px; margin-bottom:10px;">
                            <strong style="color:#C41E3A;">游玩特色：</strong><br>
                            瀑布景观、亲水徒步、夏季戏水
                        </div>
                        <div style="background:#f5f5f5; padding:8px; border-radius:6px;">
                            <strong style="color:#C41E3A;">实景影像：</strong><br>
                            <div style="width:240px; height:180px; border-radius:8px; overflow:hidden; margin:0 auto; border:1px solid #ddd; position:relative;">
                                <img src="瀑布/1.jpg" alt="百丈冲瀑布群照片1" class="waterfall-img active" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:1; transition:opacity 0.5s ease;">
                                <img src="瀑布/2.jpg" alt="百丈冲瀑布群照片2" class="waterfall-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布/3.jpg" alt="百丈冲瀑布群照片3" class="waterfall-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布/4.jpg" alt="百丈冲瀑布群照片4" class="waterfall-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                                <img src="瀑布/5.jpg" alt="百丈冲瀑布群照片5" class="waterfall-img" style="width:100%; height:100%; object-fit:cover; position:absolute; top:0; left:0; opacity:0; transition:opacity 0.5s ease;">
                            </div>
                            <div style="display:flex; justify-content:center; gap:8px; margin-top:8px;">
                                <span class="waterfall-indicator active" onclick="showWaterfallImage(0)" data-index="0" style="width:12px; height:12px; border-radius:50%; background:#C41E3A; cursor:pointer; transition: all 0.3s ease; transform: scale(1.2);"></span>
                                <span class="waterfall-indicator" onclick="showWaterfallImage(1)" data-index="1" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="waterfall-indicator" onclick="showWaterfallImage(2)" data-index="2" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="waterfall-indicator" onclick="showWaterfallImage(3)" data-index="3" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                                <span class="waterfall-indicator" onclick="showWaterfallImage(4)" data-index="4" style="width:12px; height:12px; border-radius:50%; background:#ccc; cursor:pointer; transition: all 0.3s ease;"></span>
                            </div>
                        </div>
                    </div>
                `;
                
                marker.bindPopup(popupContent, { 
                    maxWidth: 280,
                    closeOnClick: false,
                    autoClose: false,
                    closeOnEscapeKey: false
                });
                
                marker.on('popupopen', function() {
                    startWaterfallCarousel();
                });
                
                marker.on('popupclose', function() {
                    stopWaterfallCarousel();
                });
            } else {
                const popupContent = `
                    <b style="font-size:1.2rem;">${point.name}</b><br>
                    <span>${point.description}</span>
                    <div class="popup-image-placeholder"><i class="fas fa-camera"></i> 实景影像</div>
                    <small>👣 类别: ${point.category}</small>
                `;
                marker.bindPopup(popupContent, { 
                className: popupClass, 
                maxWidth: 280,
                closeOnClick: false,      // 点击地图不关闭弹窗
                autoClose: false,         // 鼠标离开标记不自动关闭
                closeOnEscapeKey: false,  // 按ESC键不关闭弹窗
                keepInView: false,        // 不自动调整位置
                className: 'no-close-popup' // 添加特殊类名
            });
            }
            
            // 鼠标悬停显示弹窗
            marker.on('mouseover', function() {
                map.getContainer().style.cursor = 'pointer';
                marker.openPopup();
            });
            
            marker.on('mouseout', function() {
                map.getContainer().style.cursor = '';
                marker.closePopup();
            });
            
            // 移除点击事件，只保留悬停显示弹窗
            marker.off('click');
            
            marker.on('popupopen', () => {
                document.getElementById('popupPreview').innerHTML = `<strong>🔍 当前预览：</strong> ${point.name}<br> <small>${point.description.substring(0,30)}…</small>`;
            });
            
            currentMarkers.push(marker);
        });

        document.getElementById('selectedInfo').innerHTML = `<strong>${route.name}</strong> (${route.duration}) <br> <span style="color:${route.color};">● 共 ${route.points.length} 个体验点</span>`;
        const listEl = document.getElementById('pointHintList');
        listEl.innerHTML = route.points.map(p => `<li><i class="fas fa-location-dot" style="color:${route.color};"></i> ${p.name} — ${p.description.substring(0,18)}…</li>`).join('');
    }

    // 渲染卡片
    const cardContainer = document.getElementById('routeCardContainer');
    BaijiRoutes.routes.forEach(route => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.borderLeftColor = route.color;
        let iconFa = 'fa-flag';
        if (route.id === 'red-tour') iconFa = 'fa-landmark';
        else if (route.id === 'nature-tour') iconFa = 'fa-tree';
        else if (route.id === 'family-tour') iconFa = 'fa-users';
        else if (route.id === 'agri-tour') iconFa = 'fa-theater-masks';
        
        card.innerHTML = `
            <i class="fas ${iconFa}" style="color:${route.color};"></i>
            <h3>${route.name}</h3>
            <span class="days" style="background:${route.color}; color:white;">${route.duration}</span>
            <p style="margin-top:10px;">点击加载路线</p>
        `;
        card.addEventListener('click', () => loadRouteMap(route.id));
        cardContainer.appendChild(card);
    });

    setTimeout(() => {
        loadRouteMap('red-tour');
    }, 200);

// 白际人民公社图片轮播功能
let communeCarouselTimer = null;
let currentCommuneImage = 0;

// 徽开古道图片轮播功能
let huikaiCarouselTimer = null;
let currentHuikaiImage = 0;

// 狮石红色教育基地图片轮播功能
let shishiCarouselTimer = null;
let currentShishiImage = 0;

// 徽州天路图片轮播功能
let huizhouCarouselTimer = null;
let currentHuizhouImage = 0;

// 严池高山梯田图片轮播功能
let terracesCarouselTimer = null;
let currentTerracesImage = 0;

// 百丈冲瀑布群图片轮播功能
let waterfallCarouselTimer = null;
let currentWaterfallImage = 0;

// 白际大峡谷图片轮播功能
let canyonCarouselTimer = null;
let currentCanyonImage = 0;

// 瀑布水枪图片轮播功能
let watergunCarouselTimer = null;
let currentWatergunImage = 0;

// 星空观测点图片轮播功能
let starCarouselTimer = null;
let currentStarImage = 0;

function showCommuneImage(index) {
    const images = document.querySelectorAll('.commune-img');
    const indicators = document.querySelectorAll('.commune-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#fb042d';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentCommuneImage = index;
}

function startCommuneCarousel() {
    stopCommuneCarousel();
    
    communeCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.commune-img');
        if (images.length > 0) {
            const nextIndex = (currentCommuneImage + 1) % images.length;
            showCommuneImage(nextIndex);
        }
    }, 1500); // 每2秒切换一次
}

function stopCommuneCarousel() {
    if (communeCarouselTimer) {
        clearInterval(communeCarouselTimer);
        communeCarouselTimer = null;
    }
}

function showHuikaiImage(index) {
    const images = document.querySelectorAll('.huikai-img');
    const indicators = document.querySelectorAll('.huikai-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentHuikaiImage = index;
}

function startHuikaiCarousel() {
    stopHuikaiCarousel();
    
    huikaiCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.huikai-img');
        if (images.length > 0) {
            const nextIndex = (currentHuikaiImage + 1) % images.length;
            showHuikaiImage(nextIndex);
        }
    }, 1500); // 每2秒切换一次
}

function stopHuikaiCarousel() {
    if (huikaiCarouselTimer) {
        clearInterval(huikaiCarouselTimer);
        huikaiCarouselTimer = null;
    }
}

function startShishiCarousel() {
    stopShishiCarousel();
    
    shishiCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.shishi-img');
        if (images.length > 0) {
            const nextIndex = (currentShishiImage + 1) % images.length;
            showShishiImage(nextIndex);
        }
    }, 2000); // 每2秒切换一次
}

function stopShishiCarousel() {
    if (shishiCarouselTimer) {
        clearInterval(shishiCarouselTimer);
        shishiCarouselTimer = null;
    }
}

function showHuizhouImage(index) {
    const images = document.querySelectorAll('.huizhou-img');
    const indicators = document.querySelectorAll('.huizhou-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentHuizhouImage = index;
}

function startHuizhouCarousel() {
    stopHuizhouCarousel();
    
    huizhouCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.huizhou-img');
        if (images.length > 0) {
            const nextIndex = (currentHuizhouImage + 1) % images.length;
            showHuizhouImage(nextIndex);
        }
    }, 2000); // 每2秒切换一次
}

function stopHuizhouCarousel() {
    if (huizhouCarouselTimer) {
        clearInterval(huizhouCarouselTimer);
        huizhouCarouselTimer = null;
    }
}

function showTerracesImage(index) {
    const images = document.querySelectorAll('.terraces-img');
    const indicators = document.querySelectorAll('.terraces-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentTerracesImage = index;
}

function startTerracesCarousel() {
    stopTerracesCarousel();
    
    terracesCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.terraces-img');
        if (images.length > 0) {
            const nextIndex = (currentTerracesImage + 1) % images.length;
            showTerracesImage(nextIndex);
        }
    }, 1500); // 每2秒切换一次
}

function stopTerracesCarousel() {
    if (terracesCarouselTimer) {
        clearInterval(terracesCarouselTimer);
        terracesCarouselTimer = null;
    }
}

function showWaterfallImage(index) {
    const images = document.querySelectorAll('.waterfall-img');
    const indicators = document.querySelectorAll('.waterfall-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentWaterfallImage = index;
}

function startWaterfallCarousel() {
    stopWaterfallCarousel();
    
    waterfallCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.waterfall-img');
        if (images.length > 0) {
            const nextIndex = (currentWaterfallImage + 1) % images.length;
            showWaterfallImage(nextIndex);
        }
    }, 2000); // 每2秒切换一次
}

function stopWaterfallCarousel() {
    if (waterfallCarouselTimer) {
        clearInterval(waterfallCarouselTimer);
        waterfallCarouselTimer = null;
    }
}

// 白际大峡谷图片轮播函数
function showCanyonImage(index) {
    const images = document.querySelectorAll('.canyon-img');
    const indicators = document.querySelectorAll('.canyon-indicator');
    
    if (images.length === 0 || indicators.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 重置所有指示器
    indicators.forEach(indicator => {
        indicator.style.background = '#ccc';
        indicator.style.transform = 'scale(1)';
        indicator.classList.remove('active');
    });
    
    // 显示选中的图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 高亮选中的指示器
    if (indicators[index]) {
        indicators[index].style.background = '#C41E3A';
        indicators[index].style.transform = 'scale(1.2)';
        indicators[index].classList.add('active');
    }
    
    // 更新当前图片索引
    currentCanyonImage = index;
}

function startCanyonCarousel() {
    // 先清除可能存在的定时器
    stopCanyonCarousel();
    
    // 设置自动轮播
    canyonCarouselTimer = setInterval(() => {
        currentCanyonImage = (currentCanyonImage + 1) % 5;
        showCanyonImage(currentCanyonImage);
    }, 2000); // 2秒切换一次
}

function stopCanyonCarousel() {
    if (canyonCarouselTimer) {
        clearInterval(canyonCarouselTimer);
        canyonCarouselTimer = null;
    }
}

// 瀑布水枪图片轮播函数
function showWatergunImage(index) {
    const images = document.querySelectorAll('.watergun-img');
    const indicators = document.querySelectorAll('.watergun-indicator');
    
    if (images.length === 0 || indicators.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 重置所有指示器
    indicators.forEach(indicator => {
        indicator.style.background = '#ccc';
        indicator.style.transform = 'scale(1)';
        indicator.classList.remove('active');
    });
    
    // 显示选中的图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 高亮选中的指示器
    if (indicators[index]) {
        indicators[index].style.background = '#C41E3A';
        indicators[index].style.transform = 'scale(1.2)';
        indicators[index].classList.add('active');
    }
    
    // 更新当前图片索引
    currentWatergunImage = index;
}

function startWatergunCarousel() {
    // 先清除可能存在的定时器
    stopWatergunCarousel();
    
    // 设置自动轮播
    watergunCarouselTimer = setInterval(() => {
        currentWatergunImage = (currentWatergunImage + 1) % 5;
        showWatergunImage(currentWatergunImage);
    }, 2000); // 2秒切换一次
}

function stopWatergunCarousel() {
    if (watergunCarouselTimer) {
        clearInterval(watergunCarouselTimer);
        watergunCarouselTimer = null;
    }
}

// 星空观测点图片轮播函数
function showStarImage(index) {
    const images = document.querySelectorAll('.star-img');
    const indicators = document.querySelectorAll('.star-indicator');
    
    if (images.length === 0 || indicators.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 重置所有指示器
    indicators.forEach(indicator => {
        indicator.style.background = '#ccc';
        indicator.style.transform = 'scale(1)';
        indicator.classList.remove('active');
    });
    
    // 显示选中的图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 高亮选中的指示器
    if (indicators[index]) {
        indicators[index].style.background = '#C41E3A';
        indicators[index].style.transform = 'scale(1.2)';
        indicators[index].classList.add('active');
    }
    
    // 更新当前图片索引
    currentStarImage = index;
}

function startStarCarousel() {
    // 先清除可能存在的定时器
    stopStarCarousel();
    
    // 设置自动轮播
    starCarouselTimer = setInterval(() => {
        currentStarImage = (currentStarImage + 1) % 5;
        showStarImage(currentStarImage);
    }, 2000); // 2秒切换一次
}

function stopStarCarousel() {
    if (starCarouselTimer) {
        clearInterval(starCarouselTimer);
        starCarouselTimer = null;
    }
}

function showHuizhouImage(index) {
    const images = document.querySelectorAll('.huizhou-img');
    const indicators = document.querySelectorAll('.huizhou-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentHuizhouImage = index;
}

function startHuizhouCarousel() {
    stopHuizhouCarousel();
    
    huizhouCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.huizhou-img');
        if (images.length > 0) {
            const nextIndex = (currentHuizhouImage + 1) % images.length;
            showHuizhouImage(nextIndex);
        }
    }, 1500); // 每2秒切换一次
}

function stopHuizhouCarousel() {
    if (huizhouCarouselTimer) {
        clearInterval(huizhouCarouselTimer);
        huizhouCarouselTimer = null;
    }
}

function showShishiImage(index) {
    const images = document.querySelectorAll('.shishi-img');
    const indicators = document.querySelectorAll('.shishi-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentShishiImage = index;
}

function startShishiCarousel() {
    stopShishiCarousel();
    
    shishiCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.shishi-img');
        if (images.length > 0) {
            const nextIndex = (currentShishiImage + 1) % images.length;
            showShishiImage(nextIndex);
        }
    }, 1500); // 每2秒切换一次
}

function stopShishiCarousel() {
    if (shishiCarouselTimer) {
        clearInterval(shishiCarouselTimer);
        shishiCarouselTimer = null;
    }
}

// 传统榨油坊轮播函数
let oilmillCarouselTimer = null;
let currentOilmillImage = 0;

function showOilmillImage(index) {
    const images = document.querySelectorAll('.oilmill-img');
    const indicators = document.querySelectorAll('.oilmill-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentOilmillImage = index;
}

function startOilmillCarousel() {
    stopOilmillCarousel();
    
    oilmillCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.oilmill-img');
        if (images.length > 0) {
            currentOilmillImage = (currentOilmillImage + 1) % images.length;
            showOilmillImage(currentOilmillImage);
        }
    }, 2000); // 2秒切换一次
}

function stopOilmillCarousel() {
    if (oilmillCarouselTimer) {
        clearInterval(oilmillCarouselTimer);
        oilmillCarouselTimer = null;
    }
}

// 土灶大锅饭轮播函数
let firecookingCarouselTimer = null;
let currentFirecookingImage = 0;

function showFirecookingImage(index) {
    const images = document.querySelectorAll('.firecooking-img');
    const indicators = document.querySelectorAll('.firecooking-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentFirecookingImage = index;
}

function startFirecookingCarousel() {
    stopFirecookingCarousel();
    
    firecookingCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.firecooking-img');
        if (images.length > 0) {
            currentFirecookingImage = (currentFirecookingImage + 1) % images.length;
            showFirecookingImage(currentFirecookingImage);
        }
    }, 2000); // 2秒切换一次
}

function stopFirecookingCarousel() {
    if (firecookingCarouselTimer) {
        clearInterval(firecookingCarouselTimer);
        firecookingCarouselTimer = null;
    }
}

// 采茶制茶轮播函数
let teaCarouselTimer = null;
let currentTeaImage = 0;

function showTeaImage(index) {
    const images = document.querySelectorAll('.tea-img');
    const indicators = document.querySelectorAll('.tea-indicator');
    
    if (images.length === 0) return;
    
    // 隐藏所有图片
    images.forEach(img => {
        img.style.opacity = '0';
        img.classList.remove('active');
    });
    
    // 显示当前图片
    if (images[index]) {
        images[index].style.opacity = '1';
        images[index].classList.add('active');
    }
    
    // 更新圆点颜色：当前圆点变红并放大，其他圆点灰色
    indicators.forEach((indicator, i) => {
        if (i === index) {
            // 当前圆点：红色并放大
            indicator.style.background = '#C41E3A';
            indicator.style.transform = 'scale(1.2)';
            indicator.classList.add('active');
        } else {
            // 其他圆点：灰色并正常大小
            indicator.style.background = '#ccc';
            indicator.style.transform = 'scale(1)';
            indicator.classList.remove('active');
        }
    });
    
    currentTeaImage = index;
}

function startTeaCarousel() {
    stopTeaCarousel();
    
    teaCarouselTimer = setInterval(() => {
        const images = document.querySelectorAll('.tea-img');
        if (images.length > 0) {
            currentTeaImage = (currentTeaImage + 1) % images.length;
            showTeaImage(currentTeaImage);
        }
    }, 2000); // 2秒切换一次
}

function stopTeaCarousel() {
    if (teaCarouselTimer) {
        clearInterval(teaCarouselTimer);
        teaCarouselTimer = null;
    }
}

    // 特产渲染
    const scrollDiv = document.getElementById('specialtyScroll');
    BaijiRoutes.specialties.forEach(item => {
        const chip = document.createElement('div');
        chip.className = 'specialty-item';
        let icon = 'fa-apple';
        if (item.includes('红薯')) icon = 'fa-sweet-potato';
        else if (item.includes('笋')) icon = 'fa-seedling';
        else if (item.includes('鸡蛋')) icon = 'fa-egg';
        else if (item.includes('茶')) icon = 'fa-mug-hot';
        else if (item.includes('葛粉')) icon = 'fa-mortar-pestle';
        chip.innerHTML = `<i class="fas ${icon}"></i>${item}`;
        scrollDiv.appendChild(chip);
    });
    
    // AI客服功能
    function initAIService() {
        const aiServiceBtn = document.getElementById('aiServiceBtn');
        const aiServicePanel = document.getElementById('aiServicePanel');
        const aiServiceClose = document.getElementById('aiServiceClose');
        const aiServiceInput = document.getElementById('aiServiceInput');
        const aiServiceSend = document.getElementById('aiServiceSend');
        const aiServiceMessages = document.getElementById('aiServiceMessages');
        
        // 检查元素是否存在
        if (!aiServiceBtn || !aiServicePanel) {
            // 如果元素不存在，等待DOM加载完成后再尝试
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initAIService);
            }
            return;
        }
        
        // 显示/隐藏客服面板
        aiServiceBtn.addEventListener('click', function() {
            aiServicePanel.classList.toggle('active');
        });
        
        aiServiceClose.addEventListener('click', function() {
            aiServicePanel.classList.remove('active');
        });
        
        // 点击面板外部关闭
        document.addEventListener('click', function(e) {
            if (!aiServicePanel.contains(e.target) && !aiServiceBtn.contains(e.target)) {
                aiServicePanel.classList.remove('active');
            }
        });
        
        // 发送消息
        function sendMessage() {
            if (!aiServiceInput) return;
            
            const message = aiServiceInput.value.trim();
            if (message) {
                // 添加用户消息
                addMessage('user', message);
                aiServiceInput.value = '';
                
                // 模拟AI思考
                setTimeout(() => {
                    const aiResponse = getAIResponse(message);
                    addMessage('ai', aiResponse);
                }, 800);
            }
        }
        
        // 添加消息到聊天界面
        function addMessage(type, content) {
            if (!aiServiceMessages) return;
            
            const messageDiv = document.createElement('div');
            messageDiv.className = type === 'ai' ? 'ai-message' : 'user-message';
            messageDiv.innerHTML = `<div class="message-content">${content}</div>`;
            
            aiServiceMessages.appendChild(messageDiv);
            
            // 滚动到底部
            aiServiceMessages.scrollTop = aiServiceMessages.scrollHeight;
            
            // 添加动画效果
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = type === 'ai' ? 'translateX(-20px)' : 'translateX(20px)';
            
            setTimeout(() => {
                messageDiv.style.transition = 'all 0.3s ease';
                messageDiv.style.opacity = '1';
                messageDiv.style.transform = 'translateX(0)';
            }, 10);
        }
        
        // 简单的AI回复逻辑
        function getAIResponse(message) {
            message = message.toLowerCase();
            
            // 旅游路线相关
            if (message.includes('路线') || message.includes('旅游') || message.includes('行程')) {
                if (message.includes('红色') || message.includes('党建')) {
                    return '我们有红色党建路线，包括白际人民公社旧址、狮石红色教育基地等景点，适合党员学习和团队建设。';
                } else if (message.includes('自驾') || message.includes('探险')) {
                    return '自驾探险路线包括徽州天路观景台、百丈冲瀑布群等景点，沿途风景优美，适合喜欢自驾的游客。';
                } else if (message.includes('非遗') || message.includes('体验')) {
                    return '非遗体验路线包括传统榨油坊、采茶制茶等体验项目，让您了解白际乡的传统文化。';
                } else if (message.includes('亲子') || message.includes('遛娃')) {
                    return '亲子遛娃路线包括严池高山梯田、白际大峡谷等景点，适合带孩子一起游玩，增进亲子感情。';
                } else {
                    return '我们有四条特色旅游路线：红色党建、自驾探险、非遗体验和亲子遛娃。您可以根据兴趣选择适合的路线。';
                }
            }
            
            // 景点相关
            if (message.includes('白际人民公社')) {
                return '白际人民公社旧址是白际乡的重要历史景点，展示了当年的公社文化，还有实景照片可以参观。';
            } else if (message.includes('徽开古道')) {
                return '徽开古道是一条历史悠久的徒步路线，连接徽州和开化，沿途风景秀丽，适合徒步爱好者。';
            } else if (message.includes('狮石')) {
                return '狮石红色教育基地是白际乡的红色景点，展示了当地的革命历史，适合党员学习。';
            } else if (message.includes('徽州天路')) {
                return '徽州天路是一条风景优美的公路，沿途有多个观景台，可以欣赏到白际乡的美丽风光。';
            } else if (message.includes('严池')) {
                return '严池高山梯田是白际乡的特色景点，春天可以看到油菜花海，夏天可以看到翡翠梯田，秋天可以看到金色稻浪。';
            } else if (message.includes('瀑布')) {
                return '百丈冲瀑布群是白际乡的自然景观，瀑布飞流直下，景色壮观，夏天可以在此戏水纳凉。';
            }
            
            // 特产相关
            if (message.includes('特产') || message.includes('产品') || message.includes('购买')) {
                return '白际乡的特产有高山红薯、野生葛粉、土鸡蛋、白茶等，都是当地的特色产品，品质优良。';
            }
            
            // 住宿相关
            if (message.includes('住宿') || message.includes('酒店') || message.includes('民宿')) {
                return '白际乡有多家民宿和农家乐，环境优美，设施齐全，可以体验当地的农家生活。';
            }
            
            // 交通相关
            if (message.includes('交通') || message.includes('怎么去') || message.includes('路线')) {
                return '前往白际乡可以自驾或乘坐公共交通。自驾可以通过徽州天路到达，公共交通可以先到歙县再转乘班车。';
            }
            
            // 天气相关
            if (message.includes('天气') || message.includes('气候')) {
                return '白际乡属于亚热带季风气候，四季分明，春季温暖湿润，夏季凉爽宜人，秋季天高气爽，冬季寒冷但不下雪。';
            }
            
            // 其他问题
            if (message.includes('你好') || message.includes('您好') || message.includes('hi') || message.includes('hello')) {
                return '您好！我是白际乡旅游平台的AI客服，有什么可以帮您的吗？';
            } else if (message.includes('谢谢') || message.includes('感谢')) {
                return '不客气，很高兴能帮到您！如果您还有其他问题，随时可以问我。';
            } else if (message.includes('再见') || message.includes('bye')) {
                return '再见！欢迎您来白际乡旅游，祝您旅途愉快！';
            } else {
                return '感谢您的咨询。关于白际乡旅游，我可以为您提供路线推荐、景点介绍、特产信息等服务，请问您想了解哪方面的内容？';
            }
        }
        
        // 发送按钮点击事件
        if (aiServiceSend) {
            aiServiceSend.addEventListener('click', sendMessage);
        }
        
        // 回车键发送消息
        if (aiServiceInput) {
            aiServiceInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
        }
    }
    
    // 初始化AI客服
    initAIService();

    document.getElementById('exploreBtn').addEventListener('click', () => {
        document.getElementById('routes-section').scrollIntoView({ behavior: 'smooth' });
    });
    
    // 登录弹窗功能
    const loginModal = document.getElementById('loginModal');
    const loginBtn = document.getElementById('loginBtn');
    const closeBtn = document.querySelector('.close-btn');
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // 打开登录弹窗
    loginBtn.addEventListener('click', function() {
        loginModal.style.display = 'block';
        // 聚焦到第一个输入框
        setTimeout(() => {
            const firstInput = document.querySelector('.tab-content.active input');
            if (firstInput) firstInput.focus();
        }, 300);
    });
    
    // 关闭登录弹窗
    closeBtn.addEventListener('click', function() {
        loginModal.style.display = 'none';
    });
    
    // 点击弹窗外部关闭
    window.addEventListener('click', function(event) {
        if (event.target === loginModal) {
            loginModal.style.display = 'none';
        }
    });
    
    // 标签页切换
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // 移除所有标签页的active类
            tabBtns.forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
            
            // 添加当前标签页的active类
            this.classList.add('active');
            document.getElementById(tabId + '-tab').style.display = 'block';
        });
    });
    
    // 忘记密码链接点击事件
    const forgotPasswordLink = document.querySelector('.forgot-password');
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 获取当前登录表单中的用户名
            const loginUsername = document.getElementById('login-username').value;
            
            // 隐藏所有标签页按钮（除了登录和注册）
            tabBtns.forEach(b => b.style.display = 'block');
            
            // 隐藏所有内容
            document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
            
            // 显示忘记密码标签页内容
            document.getElementById('forgot-tab').style.display = 'block';
            
            // 如果登录表单中有用户名，自动填充到忘记密码表单
            if (loginUsername) {
                document.getElementById('forgot-username').value = loginUsername;
            }
        });
    }
    
    // 缓存注册用户列表
    let registeredUsersCache = null;
    
    // 获取注册用户列表（带缓存）
    function getRegisteredUsers() {
        if (registeredUsersCache === null) {
            try {
                const users = localStorage.getItem('registeredUsers');
                registeredUsersCache = users ? JSON.parse(users) : [];
            } catch (e) {
                console.warn('读取注册用户失败:', e);
                registeredUsersCache = [];
            }
        }
        return registeredUsersCache;
    }
    
    // 保存注册用户列表
    function saveRegisteredUsers(users) {
        registeredUsersCache = users;
        // 使用try-catch避免localStorage错误
        try {
            localStorage.setItem('registeredUsers', JSON.stringify(users));
        } catch (e) {
            console.warn('保存注册用户失败:', e);
        }
    }
    
    // 检查用户是否已注册
    function isUserRegistered(username) {
        const users = getRegisteredUsers();
        return users.some(user => user.username === username);
    }
    
    // 检查用户密码是否正确
    function checkUserPassword(username, password) {
        const users = getRegisteredUsers();
        const user = users.find(user => user.username === username);
        return user && user.password === password;
    }
    
    // 检查本地存储中的登录信息（优化版）
    function checkRememberedLogin() {
        try {
            const rememberedUser = localStorage.getItem('rememberedUser');
            if (rememberedUser) {
                const userData = JSON.parse(rememberedUser);
                // 自动登录
                const loginBtn = document.getElementById('loginBtn');
                const userInfo = document.getElementById('userInfo');
                const userName = document.getElementById('userName');
                
                if (loginBtn && userInfo && userName) {
                    loginBtn.style.display = 'none';
                    userInfo.style.display = 'flex';
                    userName.textContent = userData.username;
                    
                    // 弹出登录成功的弹窗，与手动登录保持一致
            setTimeout(() => {
                autoAlert('登录成功！欢迎回来，' + userData.username, 'success');
            }, 500); // 延迟一下，让页面加载更自然
                    
                    console.log('自动登录成功:', userData);
                }
            }
        } catch (e) {
            console.warn('自动登录失败:', e);
        }
    }
    
    // 页面加载时检查自动登录（异步执行）
    setTimeout(checkRememberedLogin, 200);
    
    // 登录表单提交（优化版）
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // 立即获取表单数据
            const username = document.getElementById('login-username').value.trim();
            const password = document.getElementById('login-password').value;
            const rememberMe = document.querySelector('input[type="checkbox"]').checked;
            
            // 简单的表单验证
            if (!username || !password) {
                autoAlert('请输入用户名和密码', 'error');
                return;
            }
            
            // 检查用户是否已注册（使用缓存）
            if (!isUserRegistered(username)) {
                autoAlert('您还没有注册', 'error');
                return;
            }
            
            // 检查密码是否正确（使用缓存）
            if (!checkUserPassword(username, password)) {
                autoAlert('密码错误', 'error');
                return;
            }
            
            // 立即关闭弹窗
            loginModal.style.display = 'none';
            
            // 更新UI（显示用户信息）
            const loginBtn = document.getElementById('loginBtn');
            const userInfo = document.getElementById('userInfo');
            const userName = document.getElementById('userName');
            
            if (loginBtn && userInfo && userName) {
                loginBtn.style.display = 'none';
                userInfo.style.display = 'flex';
                userName.textContent = username;
            }
            
            // 异步处理本地存储
            if (rememberMe) {
                setTimeout(() => {
                    try {
                        // 保存登录信息到本地存储
                        const userData = {
                            username: username,
                            // 注意：实际应用中不要存储密码，这里仅作演示
                            password: password,
                            loginTime: new Date().toISOString()
                        };
                        localStorage.setItem('rememberedUser', JSON.stringify(userData));
                    } catch (e) {
                        console.warn('保存登录信息失败:', e);
                    }
                }, 0);
            }
            
            // 显示登录成功提示
            autoAlert('登录成功！欢迎回来，' + username, 'success');
            
            // 这里可以添加实际的登录逻辑
            console.log('登录信息:', { username, password, rememberMe });
        });
    }
    
    // 注册表单提交
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm-password').value;
            
            // 简单的表单验证
            if (!username || !password || !confirmPassword) {
                autoAlert('请填写所有字段', 'error');
                return;
            }
            
            if (password !== confirmPassword) {
                autoAlert('两次输入的密码不一致', 'error');
                return;
            }
            
            // 检查用户名是否已存在
            if (isUserRegistered(username)) {
                autoAlert('用户名已存在，请选择其他用户名', 'error');
                return;
            }
            
            // 保存新用户到注册列表
            const users = getRegisteredUsers();
            users.push({
                username: username,
                // 注意：实际应用中应加密存储密码
                password: password,
                registerTime: new Date().toISOString()
            });
            saveRegisteredUsers(users);
            console.log('新用户注册成功:', username);
            
            // 模拟注册成功
            autoAlert('注册成功！欢迎加入，' + username, 'success');
            loginModal.style.display = 'none';
            
            // 显示用户信息，隐藏登录按钮
            document.getElementById('loginBtn').style.display = 'none';
            document.getElementById('userInfo').style.display = 'flex';
            document.getElementById('userName').textContent = username;
            
            // 这里可以添加实际的注册逻辑
            console.log('注册信息:', { username, email, password });
        });
    }
    
    // 忘记密码表单提交
    const forgotForm = document.getElementById('forgotForm');
    if (forgotForm) {
        forgotForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('forgot-username').value;
            const newPassword = document.getElementById('forgot-new-password').value;
            const confirmPassword = document.getElementById('forgot-confirm-password').value;
            
            // 简单的表单验证
            if (!username || !newPassword || !confirmPassword) {
                autoAlert('请填写所有字段', 'error');
                return;
            }
            
            if (newPassword !== confirmPassword) {
                autoAlert('两次输入的密码不一致', 'error');
                return;
            }
            
            // 检查用户是否已注册
            if (!isUserRegistered(username)) {
                autoAlert('用户名不存在', 'error');
                return;
            }
            
            // 更新用户密码
            const users = getRegisteredUsers();
            const userIndex = users.findIndex(user => user.username === username);
            if (userIndex !== -1) {
                users[userIndex].password = newPassword; // 注意：实际应用中应加密存储
                users[userIndex].passwordUpdateTime = new Date().toISOString();
                saveRegisteredUsers(users);
                console.log('密码重置成功:', username);
                
                // 显示重置成功提示
                autoAlert('密码重置成功！请使用新密码登录', 'success');
                
                // 切换回登录标签页
                tabBtns.forEach(b => {
                    b.classList.remove('active');
                    b.style.display = 'block'; // 确保所有标签页按钮都显示
                });
                document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
                
                // 激活登录标签页
                const loginTabBtn = document.querySelector('[data-tab="login"]');
                if (loginTabBtn) {
                    loginTabBtn.classList.add('active');
                }
                document.getElementById('login-tab').style.display = 'block';
                
                // 将用户名填充到登录表单
                document.getElementById('login-username').value = username;
                document.getElementById('login-password').value = '';
                document.getElementById('login-password').focus();
            }
        });
    }
    
    // 显示自动消失弹窗函数（优化版）
    function autoAlert(message, type = 'info') {
        const container = document.getElementById('autoAlertContainer');
        if (!container) return;
        
        // 创建弹窗元素
        const alert = document.createElement('div');
        alert.className = `auto-alert ${type}`;
        alert.style.position = 'relative';
        alert.style.zIndex = Date.now(); // 确保新弹窗在最上层
        
        alert.innerHTML = `
            <div class="auto-alert-content">
                ${message}
            </div>
        `;
        
        // 清空容器，只显示最新的弹窗
        container.innerHTML = '';
        container.appendChild(alert);
        
        // 3秒后自动移除
        setTimeout(() => {
            try {
                if (alert.parentNode === container) {
                    // 添加淡出动画
                    alert.style.opacity = '0';
                    alert.style.transition = 'opacity 0.3s ease';
                    
                    // 动画结束后移除
                    setTimeout(() => {
                        if (alert.parentNode) {
                            alert.parentNode.removeChild(alert);
                        }
                    }, 300);
                }
            } catch (e) {
                console.warn('移除弹窗时出错:', e);
            }
        }, 3000);
    }
    
    // 登出功能
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // 确认登出
            if (confirm('确定要退出登录吗？')) {
                // 显示登录按钮，隐藏用户信息
                document.getElementById('loginBtn').style.display = 'block';
                document.getElementById('userInfo').style.display = 'none';
                
                // 清除本地存储中的登录信息
                localStorage.removeItem('rememberedUser');
                console.log('已清除本地存储的登录信息');
                
                autoAlert('已成功退出登录', 'success');
            }
        });
    }
    
    // 用户留言板功能
    const messageForm = document.getElementById('messageForm');
    const messageItems = document.getElementById('messageItems');
    const submitMessageBtn = document.getElementById('submitMessageBtn');
    
    // 缓存数据
    let messagesCache = null;
    
    // 获取留言列表（带缓存）
    function getMessages() {
        if (messagesCache === null) {
            const messages = localStorage.getItem('messages');
            messagesCache = messages ? JSON.parse(messages) : [];
        }
        return messagesCache;
    }
    
    // 保存留言列表
    function saveMessages(messages) {
        messagesCache = messages;
        // 使用try-catch避免localStorage错误
        try {
            localStorage.setItem('messages', JSON.stringify(messages));
        } catch (e) {
            console.warn('保存留言失败:', e);
        }
    }
    
    // 渲染留言列表（优化DOM操作）
    function renderMessages() {
        const messages = getMessages();
        
        if (messages.length === 0) {
            messageItems.innerHTML = `
                <div class="message-item empty-message">
                    <p>暂无留言，快来发表第一条留言吧！</p>
                </div>
            `;
            return;
        }
        
        // 使用文档片段批量创建DOM元素，减少重排
        const fragment = document.createDocumentFragment();
        
        messages.forEach((message, index) => {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message-item';
            messageDiv.setAttribute('data-message-id', message.id);
            
            // 构建回复列表HTML
            let repliesHTML = '';
            if (message.replies && message.replies.length > 0) {
                repliesHTML = `
                    <div class="message-replies">
                        ${message.replies.map((reply, replyIndex) => `
                            <div class="message-reply">
                                <div class="reply-header">
                                    <span class="reply-author">${reply.author}</span>
                                    <span class="reply-time">${reply.time}</span>
                                </div>
                                <div class="reply-content">${reply.content}</div>
                            </div>
                        `).join('')}
                    </div>
                `;
            }
            
            messageDiv.innerHTML = `
                <div class="message-header">
                    <span class="message-author">${message.author}</span>
                    <span class="message-time">${message.time}</span>
                </div>
                <div class="message-content">${message.content}</div>
                ${repliesHTML}
                <div class="message-actions">
                    <button class="btn-reply" data-index="${index}"><i class="fas fa-reply"></i> 回复</button>
                    <button class="btn-delete" data-index="${index}"><i class="fas fa-trash-alt"></i> 删除</button>
                </div>
                <div class="reply-form" style="display: none;">
                    <textarea class="reply-content-input" placeholder="写下你的回复..."></textarea>
                    <div class="reply-form-actions">
                        <button class="btn-cancel-reply">取消</button>
                        <button class="btn-submit-reply" data-index="${index}">提交回复</button>
                    </div>
                </div>
            `;
            fragment.appendChild(messageDiv);
        });
        
        // 一次性更新DOM
        messageItems.innerHTML = '';
        messageItems.appendChild(fragment);
    }
    
    // 只添加一次事件监听器（事件委托）
    if (messageItems) {
        messageItems.addEventListener('click', function(e) {
            // 处理删除按钮点击
            if (e.target.closest('.btn-delete')) {
                const btn = e.target.closest('.btn-delete');
                const index = parseInt(btn.getAttribute('data-index'));
                deleteMessage(index);
            }
            
            // 处理回复按钮点击
            if (e.target.closest('.btn-reply')) {
                const btn = e.target.closest('.btn-reply');
                const messageItem = btn.closest('.message-item');
                const replyForm = messageItem.querySelector('.reply-form');
                
                // 显示/隐藏回复表单
                if (replyForm) {
                    replyForm.style.display = replyForm.style.display === 'none' ? 'block' : 'none';
                }
            }
            
            // 处理取消回复按钮点击
            if (e.target.closest('.btn-cancel-reply')) {
                const btn = e.target.closest('.btn-cancel-reply');
                const replyForm = btn.closest('.reply-form');
                
                if (replyForm) {
                    replyForm.style.display = 'none';
                }
            }
            
            // 处理提交回复按钮点击
            if (e.target.closest('.btn-submit-reply')) {
                const btn = e.target.closest('.btn-submit-reply');
                const index = parseInt(btn.getAttribute('data-index'));
                const messageItem = btn.closest('.message-item');
                const replyContentInput = messageItem.querySelector('.reply-content-input');
                const replyContent = replyContentInput.value.trim();
                
                if (replyContent) {
                    addReply(index, replyContent);
                    // 清空输入框并隐藏表单
                    replyContentInput.value = '';
                    const replyForm = btn.closest('.reply-form');
                    if (replyForm) {
                        replyForm.style.display = 'none';
                    }
                } else {
                    autoAlert('请输入回复内容', 'error');
                }
            }
        });
    }
    
    // 添加回复函数
    function addReply(messageIndex, content) {
        // 检查登录状态
        const user = checkLoginStatus();
        if (!user) {
            autoAlert('请先登录后再发表回复', 'error');
            // 打开登录弹窗
            document.getElementById('loginBtn').click();
            return;
        }
        
        // 获取留言列表
        const messages = getMessages();
        const message = messages[messageIndex];
        
        if (message) {
            // 确保回复数组存在
            if (!message.replies) {
                message.replies = [];
            }
            
            // 创建回复对象
            const reply = {
                id: Date.now().toString(),
                author: user.username,
                content: content,
                time: new Date().toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                })
            };
            
            // 添加回复
            message.replies.unshift(reply); // 新回复放在最前面
            
            // 保存并重新渲染
            saveMessages(messages);
            renderMessages();
            autoAlert('回复成功！', 'success');
        }
    }
    
 // 删除留言
function deleteMessage(index) {
    if (confirm('确定要删除这条留言吗？')) {
        const messages = getMessages();
        messages.splice(index, 1);
        saveMessages(messages);
        renderMessages();
        autoAlert('留言已删除', 'success');
    }
}

    
    // 检查登录状态（优化版）
    function checkLoginStatus() {
        // 首先检查用户信息元素是否显示（表示当前已登录）
        const userInfo = document.getElementById('userInfo');
        if (userInfo && userInfo.style.display !== 'none') {
            const userName = document.getElementById('userName').textContent;
            if (userName) {
                return { username: userName };
            }
        }
        
        // 然后检查本地存储
        try {
            const rememberedUser = localStorage.getItem('rememberedUser');
            if (rememberedUser) {
                return JSON.parse(rememberedUser);
            }
        } catch (e) {
            console.warn('读取登录状态失败:', e);
        }
        
        return null;
    }
    
    // 留言表单提交
    if (messageForm) {
        messageForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // 检查登录状态
            const user = checkLoginStatus();
            if (!user) {
                autoAlert('请先登录后再发表留言', 'error');
                // 打开登录弹窗
                document.getElementById('loginBtn').click();
                return;
            }
            
            const content = document.getElementById('message-content').value.trim();
            if (!content) {
                autoAlert('请输入留言内容', 'error');
                return;
            }
            
            // 创建留言对象
            const message = {
                id: Date.now().toString(),
                author: user.username,
                content: content,
                time: new Date().toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit'
                }),
                replies: [] // 添加回复数组
            };
            
            // 添加到留言列表
            const messages = getMessages();
            messages.unshift(message); // 新留言放在最前面
            saveMessages(messages);
            
            // 清空表单
            document.getElementById('message-content').value = '';
            
            // 重新渲染留言列表
            renderMessages();
            
            autoAlert('留言发布成功！', 'success');
        });
    }
    
    // 页面加载时渲染留言列表（异步执行）
    setTimeout(renderMessages, 100);
                // 图片加载检测（可选，帮助调试）
    window.addEventListener('load', function() {
        const images = [
            './bannerimages/山里3.png',
            './bannerimages/星空2.avif',
            './bannerimages/茶园2.jpg',
            './bannerimages/茶园3.jpg',
            './bannerimages/梯田1.jpg'
        ];
        images.forEach(src => {
            const img = new Image();
            img.onload = () => console.log('✅ 图片加载成功:', src);
            img.onerror = () => console.warn('⚠️ 图片加载失败，请检查路径:', src);
            img.src = src;
        });
    });
})();